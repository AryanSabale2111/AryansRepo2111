from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    math = float(request.form['math'])
    science = float(request.form['science'])
    english = float(request.form['english'])
    interest = float(request.form['interest'])

    features = np.array([[math, science, english, interest]])
    prediction = model.predict(features)[0]

    return render_template('result.html', recommendation=prediction)

if __name__ == '__main__':
    app.run(debug=True)
